const mysql = require("mysql2");
let path = require('path')
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
app.set('view engine', 'ejs');
app.set('views',path.join(__dirname,'views'))
app.use(bodyParser.urlencoded({extended:true}))

const sqlConnection = mysql.createConnection({
    host : 'localhost',
    user:'root',                          
    password: '789789789', // please make a new schema named itfactori in your mysclqorkbench,in the schema there must be 3 tables as of now : employee ,offices , customers
    database: 'itfactori'  
});

app.get('/',(req,res)=>{
    res.render('pages/home');
});
// 
// login routes
app.get('/login',(req,res)=>{
    res.render('pages/loginPageFinal.ejs')
})
app.post('/login',(req,res)=>{
    if (req.body.password === 'database'){
        res.redirect('/')
    }else{
        res.render('pages/error',{name:req.body.name})
    }
})

app.get('/eventlog',(req,res)=>{
    sqlConnection.query('SELECT * FROM event_log ',(err,rows)=>{
        if (err) throw err;
        //console.log(rows);
        res.render('pages/eventlog',{rows})
    }

    )
})

// employee routes
app.get('/employee',(req,res)=>{
    sqlConnection.query('SELECT * FROM Employee ORDER BY empID',(err,rows)=>{
        if (err) throw err;
        //console.log(rows);
        res.render('pages/employee',{rows})
    })
})
 
app.post('/employee',(req,res)=>{
        console.log(req.body);
        const queryData = req.body;
        const sqlQuery = `INSERT INTO Employee(eName,email,contact,eRole,salaryID,address,officeID ) VALUES ("${queryData.eName}","${queryData.email}","${queryData.contact}","${queryData.eRole}","${queryData.salaryID}","${queryData.address}","${queryData.officeID}");`
        sqlConnection.query(sqlQuery,(err,row)=>{
                    if (err) throw err;
                    else console.log('Employee table Query insertion successful')
                })
        res.redirect('/employee')
})

app.get('/employee/insert',(req,res)=>{
    res.render('insertForms/employee.ejs')
})

app.get('/employee/delete',(req,res)=>{
    res.render('insertForms/employeeDel.ejs')
})
app.get('/employee/update',(req,res)=>{
    res.render('insertForms/employeeUpdate.ejs')
})
app.post('/employee/update',(req,res)=>{
    console.log(req.body);
    const queryData = req.body;
    const sqlQuery = `UPDATE employee SET ${queryData.column}="${queryData.updatedValue}" WHERE empID="${queryData.empID}";`;
    console.log(sqlQuery)
    sqlConnection.query(sqlQuery,(err,row)=>{
        if (err) {
            res.render('basicError',{msg:err.message});
        
    }
        else {console.log('Updating data in employee table successful')
        res.redirect('/employee')}
    })
    
})
app.post('/employee/delete',(req,res)=>{
    const queryData = req.body;
    const sqlQuery = `DELETE FROM Employee WHERE empID="${queryData.empID}"`
    sqlConnection.query(sqlQuery,(err,row)=>{
        if (err) throw err;
        else console.log('Deletion from employee table successful')
    })
        
    res.redirect('/employee');
})

// OFFICES
app.get('/offices',(req,res)=>{
    sqlConnection.query('SELECT * FROM offices',(err,rows)=>{
        if (err) throw err;
        //console.log(rows);
        res.render('pages/offices',{rows})
    })
})
app.get('/offices/insert',(req,res)=>{
    res.render('insertForms/officeInsert.ejs')
})
app.post('/offices',(req,res)=>{
    const queryData = req.body;
    const sqlQuery = `INSERT INTO Offices(oName,location,contact) VALUES ("${queryData.oName}","${queryData.location}","${queryData.contact}");`
    sqlConnection.query(sqlQuery,(err,row)=>{
                if (err) throw err;
                else console.log('Offices table Query insertion successful')
            })
    res.redirect('/offices')
})
app.get('/offices/delete',(req,res)=>{
    res.render('insertForms/officeDel.ejs')
})

app.post('/offices/delete',(req,res)=>{
    const queryData = req.body;
    const sqlQuery = `DELETE FROM Offices WHERE officeID="${queryData.officeID}"`
    sqlConnection.query(sqlQuery,(err,row)=>{
        if (err) throw err;
        else console.log('Deletion from office table successful')
    })
        
    res.redirect('/offices');
})


//Customers
app.get('/customers',(req,res)=>{
    sqlConnection.query('SELECT * FROM Customers',(err,rows)=>{
        if (err) throw err;
        //console.log(rows);
        res.render('pages/customers',{rows})
    })
})

app.post('/customers',(req,res)=>{
    console.log(req.body);
    const queryData = req.body;
    const sqlQuery = `INSERT INTO Customers(cName,email,contact,appID ) VALUES ("${queryData.cName}","${queryData.email}","${queryData.contact}","${queryData.appID}");`
    sqlConnection.query(sqlQuery,(err,row)=>{
                if (err) throw err;
                else console.log('Customers table Query insertion successful')
            })
    res.redirect('/customers')
})

app.get('/customers/insert',(req,res)=>{
res.render('insertForms/customerInsert.ejs')
})


app.get('/customers/delete',(req,res)=>{
res.render('insertForms/customerDel.ejs')
})

app.post('/customers/delete', (req,res)=>{
    const queryData = req.body;
    const sqlQuery = `DELETE FROM Customers WHERE customerID="${queryData.customerID}"`
    sqlConnection.query(sqlQuery,(err,row)=>{
        if (err) throw err;
        else console.log('Deletion from Customers table successful')
    })
        
    res.redirect('/customers');
    })

// app.get('/employee/update',(req,res)=>{
// res.render('insertForms/employeeUpdate.ejs')
// })
// app.post('/employee/update',(req,res)=>{
// console.log(req.body);
// const queryData = req.body;
// const sqlQuery = `UPDATE employee SET ${queryData.column}="${queryData.updatedValue}" WHERE empID="${queryData.empID}";`;
// console.log(sqlQuery)
// sqlConnection.query(sqlQuery,(err,row)=>{
//     if (err) {
//         res.render('basicError',{msg:err.message});  
// }
//     else {console.log('Updating data in employee table successful')
//     res.redirect('/employee')}
// })
// })




app.listen(3001, () => {
    console.log("Listening on port 3001");
  });
  



//   app.post('/',(req,res)=>{
//     //console.log('Inside post route')
//     const queryData = req.body
//     console.log(query);
//     res.send('query Successful')
//     const sqlQuery = `INSERT INTO posts(title, body) VALUES ("${queryData.ptitle}","${queryData.pbody}")`
//     // const SQLquery = `INSERT INTO posts VALUES(${queryData.ptitle},${queryData.pbody});`
//     sqlConnection.query(sqlQuery,(err,row)=>{
//         if (err) throw err;
//         else console.log('Query insertion successful')
//     })
// })












//   app.post('/',(req,res)=>{
//     console.log('Inside post route')
//     const queryData = req.body
//     console.log(query);
//     res.send('query Successful')
//     const sqlQuery = `INSERT INTO posts(title, body) VALUES ("${queryData.ptitle}","${queryData.pbody}")`
//     // const SQLquery = `INSERT INTO posts VALUES(${queryData.ptitle},${queryData.pbody});`
//     sqlConnection.query(sqlQuery,(err,row)=>{
//         if (err) throw err;
//         else console.log('Query insertion successful')
//     })
// })





// let sql = 'CREATE TABLE posts(id int AUTO_INCREMENT,title varchar(50),body varchar(50), primary key(id));'
//     db.query(sql,(err,result)=>{
//         if (err) throw err;
//         console.log(result);
//     })



// let post = {title:'post1',body:'this is post number 4'}
// let sql = 'INSERT INTO posts SET ?';
// let query = db.query(sql,post,(err,result)=>{
//                 if (err) throw err;
//                 console.log('post4 added')
//                 console.log(result)
// });

// let sql = 'SELECT * FROM posts;'
// const finalStuff = [];
// const data =  db.query(sql,(err,results)=>{
//         if (err) throw err;
//         console.log(results[1]);
//         // console.log(data,'inside function')
//         finalStuff.push(...results)
//         console.log(finalStuff)
//         return results
//     })
//     setTimeout(()=>{
//         console.log('after function execution')
//         console.log(finalStuff)
//     },100)

// // console.log(data)

// app.get('/posts',(req,res)=>{
//     res.render('pages/index',{data:finalStuff[1].title})
// })



// app.get('/createpoststable',(req,res)=>{
//     let sql = 'CREATE TABLE posts(id int AUTO_INCREMENT,title varchar(50),body varchar(50), primary key(id));'
//     db.query(sql,(err,result)=>{
//         if (err) throw err;
//         console.log(result);
//     })
// })

// app.get('/createdb',(req,res)=>{
//     let sql = 'CREATE DATABASE nodemysql';
//     db.query(sql,(err,result)=>{
//         if (err){
//             throw err;
//         }
//         console.log(result);
//         res.send('DATABASE CREATED');
//     })
// })

// db.connect((err)=>{
//     if (err){
//         throw err;
//     }console.log('MY SQL DATABASE CONNECTED')
// })


// console.log('abt to print data')
//     console.log(data)